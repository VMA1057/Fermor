# Fermor

Live Demo:
[FINAL VERCEL URL]

---

## What is Fermor?

Fermor is an interactive wealth modeling and decision platform designed to bring clarity, transparency, and tactile control to personal finance.

### Who Fermor is for
- **Young Professionals:** Navigating their first significant income, learning how to balance everyday lifestyle spending with early compounding and emergency savings.
- **Families:** Planning long-term milestones such as home ownership, children's education, and debt amortization without getting lost in predatory sales pitches.
- **Curious Investors:** Exploring macroeconomic trends, testing what-if scenarios, and understanding market dynamics before allocating hard-earned capital.

### The Problem It Solves
Traditional personal finance tools suffer from two extremes: they are either opaque, intimidating spreadsheets or aggressive lead-generation funnels disguised as "calculators." Users rarely get an intuitive feel for how a ₹5,000 monthly adjustment, a delayed purchase, or an extra 1.5% compounding rate fundamentally changes their financial trajectory 10 or 20 years down the road.

### The Product Experience
Fermor transforms financial planning into an editorial, tactile journey. Rather than filling out sterile forms, users drag intuitive sliders, explore branching timeline milestones, simulate what-if lifestyle trade-offs, and read curated market intelligence presented in a classic broadsheet financial newspaper format.

### Why It Is Different
- **Client-Side Privacy by Design:** 100% of calculations execute directly in your browser's local memory using deterministic mathematics. Fermor does not track, store, or monetize your financial inputs.
- **Editorial Aesthetic:** Fermor rejects generic fintech neon gradients and sterile dashboard grids in favor of an archival, tactile publication feel—utilizing warm paper tones, disciplined typography, and micro-interactions that feel crafted rather than assembled.
- **Dual-Perspective Modeling:** It links personal cashflows (SIPs, EMIs, SWPs) with macroeconomic context (inflation benchmarks, currency rates, policy changes).

---

## Why the Sections Are in This Order

The layout follows a deliberate narrative designed to guide the visitor from curiosity to understanding, exploration, practical validation, and action:

1. **Hero & Global Currency Dial**
   * *Establishes the Thesis:* Opens with clear value messaging and an interactive currency selector. It instantly communicates that money is dynamic, interconnected, and personal.
2. **Interactive Wealth Projection (Understand Your Trajectory)**
   * *Grounds the User in Reality:* Immediately moves from abstract promises to interactive modeling. Users adjust monthly contributions, horizons, and expected CAGRs to see the power of compounding visualized across time.
3. **What-If Scenarios (Explore Alternative Futures)**
   * *Introduces Decision Trade-Offs:* Compounding isn't linear in real life. This section allows users to simulate behavioral forks—such as upgrading a car vs. taking a sabbatical vs. increasing savings by 10%—visualizing the opportunity cost side by side.
4. **The Financial Gazette (Connect Macro to Micro)**
   * *Contextualizes External Realities:* Personal wealth does not exist in a vacuum. The broadsheet newspaper connects everyday money decisions with interest rates, inflation figures, market indices, and economic policies.
5. **Interactive Decision Suite (Practical Tools)**
   * *Delivers Focused Utility:* Provides precision instruments (SIP, EMI, Lumpsum, SWP, Retirement) so users can stress-test specific life decisions with exact numbers and schedules.
6. **Who It's For (Audience Resonance)**
   * *Validates User Intent:* Contextualizes the platform for young professionals, families, and curious investors, ensuring visitors see their exact life stage represented.
7. **Data Transparency & FAQ (Trust & Ethics)**
   * *Answers the Unspoken Concerns:* Clearly explains where calculations run (client-side), what is stored (nothing except optional waitlist emails), and how projections should be interpreted before asking for any user commitment.
8. **Waitlist & Footer (Clear Next Action)**
   * *Closes the Loop:* Once value, utility, and ethics have been demonstrated, the user is invited to join the early access waitlist with a clean, low-friction interaction.

---

## What I Cut and Why

- **Mobile WebGL 3D Globe:**
  * *Reason:* Rendering an unconstrained Three.js 3D WebGL globe on mobile viewports (< 768px) created GPU overhead, high battery drain, and potential layout shifts.
  * *Action:* On mobile devices, the WebGL canvas is safely omitted and replaced with a lightweight CSS/SVG ambient pulse ring that maintains elegance with zero performance penalty.
- **Continuous Mobile Background Particles:**
  * *Reason:* Continuous physics animation loops running across small touchscreens degraded scrolling frame rates.
  * *Action:* Mobile screens use a subtle, static radial ambient gradient instead of active Framer Motion particle loops.
- **Erratic 3D Tilt on Touch Devices:**
  * *Reason:* Coordinate-based mouse parallax tilt behaves unpredictably on touchscreens and can interfere with vertical scrolling.
  * *Action:* 3D mouse tilt is disabled on coarse pointer devices (`@media (pointer: coarse)`), replaced by subtle tap-scale (`active:scale-[0.98]`) feedback.
- **Overused Serif Typography in UI Controls:**
  * *Reason:* Early versions used DM Serif Display on body text, buttons, and numeric inputs, making numbers hard to read and diminishing visual hierarchy.
  * *Action:* Standardized all metrics, form inputs, buttons, and body descriptions to clean, highly legible Inter, reserving DM Serif Display strictly for primary editorial headlines.
- **Generic Third-Party Marketing Badges:**
  * *Reason:* Extraneous template labels and generic badges detracted from Fermor's focused editorial identity.
  * *Action:* Removed placeholder badges in favor of cohesive product terminology.

---

## Interesting Design Decisions

### Currency Globe
The interactive globe in the hero connects localized currency choices with global purchasing power. Rather than burying currency selection in a flat dropdown, the globe tangibly reminds users that currency strength and macro flows influence individual purchasing power.

### Financial Gazette
Instead of standard RSS feeds, blog carousels, or corporate marketing banners, financial news is rendered as a zoomable, tactile broadsheet newspaper. It frames market intelligence as an enduring editorial publication, reinforcing the timeless fundamentals of investing over ephemeral market noise.

### Custom Cursor
On desktop pointers, a magnetic custom cursor provides contextual feedback—morphing into an expansive ring over buttons, interactive chart zones, and broadsheet articles. On touch devices or when `prefers-reduced-motion` is enabled, the custom cursor gracefully deactivates, ensuring zero friction.

### Interactive Wealth Projection
The projection graph is structured as a milestone-driven journey rather than a generic line chart. Markers highlighting milestones (e.g., First ₹10 Lakhs, Halfway Mark, Financial Independence) celebrate progress and make compounding relatable.

### Alternate Future / What If
Behavioral economics proves that people struggle to sacrifice short-term gratification for distant rewards. The "What If" scenario tool bridges this gap by directly contrasting a baseline scenario against alternate life forks, illustrating the tangible future cost of daily habits.

---

## Known Limitations

- **Exchange Rates:** Live currency synchronization calls public exchange APIs with resilient fallback benchmark rates if network requests are unavailable or rate-limited.
- **Market & Broadsheet Data:** Broadsheet articles, sectoral insights, and market indices are powered by curated snapshot datasets rather than real-time sub-second broker feeds.
- **Educational Simulation:** All wealth projections and compounding calculations are deterministic mathematical models designed for education; they do not account for black swan events or guarantee future returns.
- **Session-Based Storage:** Financial numbers and slider settings reside exclusively in browser memory during an active session; there is currently no persistent database storage or user authentication.

---

## What I'd Do With More Time

1. **Live Market & Brokerage APIs:** Connect to live exchange webhooks (NSE/BSE, Alpha Vantage, Polygon) for real-time streaming tickers.
2. **Multi-Asset Portfolio Modeling:** Allow users to build customized asset allocations combining equities, debt, gold, and real estate with historical rebalancing backtests.
3. **User Accounts & Saved Scenarios:** Implement encrypted authentication allowing users to save, bookmark, and export scenario comparisons across sessions.
4. **Export Engine:** Generate publication-quality PDF executive summaries and CSV cashflow amortization schedules.
5. **Monte Carlo Simulations:** Supplement deterministic compounding curves with probabilistic simulations modeling market volatility distributions.
6. **Accessibility Audits & Localization:** Conduct deep automated screen-reader testing (NVDA/VoiceOver) and translate the broadsheet experience into regional Indian languages.

---

## Tech Stack

- **Framework:** Next.js 16 (App Router with Turbopack)
- **UI Library:** React 19
- **Language:** TypeScript 5
- **Styling:** Tailwind CSS v4
- **Animation & Transitions:** Framer Motion
- **3D Graphics & Canvas:** Three.js & @react-three/fiber
- **Data Visualization:** Recharts
- **Icons:** Lucide React
- **Deployment:** Vercel

---

## Running Locally

Clone the repository and install dependencies:

```bash
npm install
```

Start the development server:

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

To run code verification and build for production:

```bash
npm run lint
npm run build
```
